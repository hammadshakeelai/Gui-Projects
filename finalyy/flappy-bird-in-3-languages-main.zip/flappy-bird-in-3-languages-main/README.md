# Flappy Bird in Python, Lua, & JavaScript
This is Flappy Bird made in three different languages: Python, Lua, and JavaScript. This project was created to highlight the similarities and differences between the three languages. Feel free to use it as a reference, but be warned—the code is quite sloppy and unorganized.

These [games were made in 3 days](https://www.youtube.com/watch?v=KPq6VswMsPY) for a video showing the differences of Python, Lua, and JavaScript
![](cover_art.png)

## How to Play
* Any key to start
* Press Space to Jump

