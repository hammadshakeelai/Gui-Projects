

Player = {}

function Player:load()
	-- Load Player Assets
	player_img = love.graphics.newImage('assets/player.png')
	woosh_sfx = love.audio.newSource("assets/woosh.wav", "static")

	-- Variable Setup
	self.x = 171
	self.y = 300
	self.velocity = 0

end


function Player:update(dt)
	self:move(dt)
end


function Player:jump()
	self.velocity = -7
	love.audio.stop(woosh_sfx)
	love.audio.play(woosh_sfx)
end


function Player:move(dt)
	self.velocity = self.velocity + 0.25
	self.y = self.velocity + self.y
end


function Player:draw()
	love.graphics.draw(player_img,self.x, self.y)
end

function Player:reset()
	self.x = 171
	self.y = 300
	self.velocity = 0
end