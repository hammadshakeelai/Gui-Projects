require("player")
require("pipe")

function love.load()

	-- Load Fonts
	font = love.graphics.newFont('assets/BaiJamjuree-Bold.ttf', 60)
	love.graphics.setFont(font)

	-- Load Sounds
	slap_sfx = love.audio.newSource("assets/slap.wav", "static")
	score_sfx = love.audio.newSource("assets/score.wav", "static")

	-- Load Images
	bg_img = love.graphics.newImage('assets/background.png')
	ground_img = love.graphics.newImage('assets/ground.png')

	Player:load()
	Pipe:load()

	-- Variable Setup
	score = 0
	bg_x_pos = 0
	ground_x_pos = 0
	bg_scroll_spd = 0.5
	ground_scroll_spd = 1
	has_moved = false

end


function checkCollision(x1,y1,w1,h1, x2,y2,w2,h2)
	return x1 < x2+w2 and
		x2 < x1+w1 and
		y1 < y2+h2 and
		y2 < y1+h1
end


function love.update(dt)
	-- Background & Ground Scrolling
	bg_x_pos = bg_x_pos - bg_scroll_spd
	ground_x_pos = ground_x_pos - ground_scroll_spd

	-- Reset Background & Ground's positions
    if bg_x_pos <= -400 then
        bg_x_pos = 0
    end

    if ground_x_pos <= -400 then
        ground_x_pos = 0
    end

    -- Reset Player if too high or low
    if Player.y < -64 or Player.y > 536 then
    	game_over()
    end


    if has_moved == true then
		Player:update(dt)
		Pipe:update(dt)
	end

	-- Check if player is touching Pipe
	if checkCollision(Player.x + 3, Player.y + 4, 50, 50, Pipe.x, Pipe.y - 360, 79, 360) or checkCollision(Player.x + 3, Player.y + 4, 50, 50, Pipe.x, Pipe.y + Pipe.gap, 79, 360) then
	    game_over()
	end

	-- Increase Score
	if not Pipe.scored and Player.x > Pipe.x then
		score = score + 1
		love.audio.play(score_sfx)
		Pipe.scored = true
	end

end


function love.keypressed(key, scancode, isrepeat)
	if has_moved == false then
		has_moved = true
	end

	if key == "space" then
		Player:jump()
	end
end


function game_over()
	Player:reset()
	Pipe:reset()
	score = 0
	has_moved = false
	love.audio.play(slap_sfx)
end


function love.draw()

	-- Draw Background
	love.graphics.draw(bg_img,bg_x_pos,0)
	love.graphics.draw(bg_img,bg_x_pos + 400,0)

	-- Draw Ground
	love.graphics.draw(ground_img,ground_x_pos,536)
	love.graphics.draw(ground_img,ground_x_pos + 400,536)

	-- Draw Player
	Player:draw()

	-- Draw Pipes
	Pipe:draw()

	-- Draw Score
	local windowWidth = love.graphics.getWidth()
	local windowHeight = love.graphics.getHeight()
	love.graphics.setColor(0.196, 0.090, 0.020)
	love.graphics.printf(score, 180, 30, 400, center)
	love.graphics.setColor(1, 1, 1)


end