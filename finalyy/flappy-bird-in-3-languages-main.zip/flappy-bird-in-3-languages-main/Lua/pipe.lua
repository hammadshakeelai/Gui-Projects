Pipe = {}

function Pipe:load()
	-- Load Pipe Assets
	pipe_down_img = love.graphics.newImage('assets/pipe_down.png')
	pipe_up_img = love.graphics.newImage('assets/pipe_up.png')

	-- Variable Setup
	self.x = 600
	self.y = love.math.random(30, 280)
	self.gap = 220
	self.scored = false
	self.velocity = -1.2

end

function Pipe:update(dt)
	self.x = self.velocity + self.x

	if self.x < -pipe_up_img:getWidth() then
		self:respawn()
	end
end


function Pipe:draw()
	love.graphics.draw(pipe_down_img,self.x, 0 - pipe_down_img:getHeight() + self.y)
	love.graphics.draw(pipe_up_img,self.x, self.y + self.gap)
end


function Pipe:respawn()
	self.x = 400
	self.y = love.math.random(30, 280)
	self.gap = 220
	self.scored = false
end


function Pipe:reset()
	self.x = 600
	self.y = love.math.random(30, 280)
	self.gap = 220
	self.scored = false
end
