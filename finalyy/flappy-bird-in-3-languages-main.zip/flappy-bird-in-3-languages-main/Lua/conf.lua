
function love.conf(t)
	t.title = "FlappyLua"
	t.window.width = 400
	t.window.height = 600
end